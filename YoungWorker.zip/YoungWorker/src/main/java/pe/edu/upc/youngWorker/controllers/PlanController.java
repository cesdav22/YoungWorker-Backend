package pe.edu.upc.youngWorker.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.youngWorker.entities.Plan;
import pe.edu.upc.youngWorker.entities.Usuario;
import pe.edu.upc.youngWorker.serviceinterfaces.IPlanService;

import java.text.ParseException;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/planes")
public class PlanController {
    @Autowired
    private IPlanService pService;

    @PostMapping
    public void registrar(@RequestBody Plan p) {
        pService.insertar(p);
    }

    @GetMapping
    public List<Plan> listar() {
        return pService.listar();
    }

    @PutMapping
    public void modificar(@RequestBody Plan p){
        pService.insertar(p);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable("id")Integer id){
        pService.eliminar(id);
    }

    @PostMapping("/buscar")
    public List<Plan>buscar(@RequestBody String plan) throws ParseException {

        List<Plan> listaPlanes;
        listaPlanes = pService.buscarNombre(plan);
        return listaPlanes;

    }

    @GetMapping("{/id}")
    public Optional<Plan> listarId(@PathVariable("id") Integer id) {
        return pService.listarId(id);
    }
}
