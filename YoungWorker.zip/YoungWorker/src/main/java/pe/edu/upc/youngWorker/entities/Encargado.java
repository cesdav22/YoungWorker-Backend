package pe.edu.upc.youngWorker.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Encargados")
public class Encargado {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idEncargado;
	@Column(name = "nombreEncargado",length = 45,nullable = false)
	private String nombreEncargado;
	@Column(name = "empresa",length = 45,nullable = false)
	private String empresa;
	
	public Encargado(){
		
	}
	
	public Encargado(int idEncargado, String nombreEncargado, String empresa) {
		super();
		this.idEncargado = idEncargado;
		this.nombreEncargado = nombreEncargado;
		this.empresa = empresa;
	}


	public int getIdEncargado() {
		return idEncargado;
	}

	public void setIdEncargado(int idEncargado) {
		this.idEncargado = idEncargado;
	}

	public String getNombreEncargado() {
		return nombreEncargado;
	}

	public void setNombreEncargado(String nombreEncargado) {
		this.nombreEncargado = nombreEncargado;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}
	

}
