package pe.edu.upc.youngWorker.serviceinterfaces;
import pe.edu.upc.youngWorker.entities.Plan;

import java.util.List;
import java.util.Optional;

public interface IPlanService {


    public void insertar(Plan plan);

    List<Plan> listar();

    public void eliminar(int idPlan);


    Optional<Plan> listarId(int idPlan);

    List<Plan> buscarNombre(String nombrePlan);
}
