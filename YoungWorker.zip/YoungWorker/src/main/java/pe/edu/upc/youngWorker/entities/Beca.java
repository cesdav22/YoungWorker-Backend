package pe.edu.upc.youngWorker.entities;

import javax.persistence.*;

@Entity
@Table(name = "Beca")
public class Beca {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idBeca;
    @Column(name = "infoBeca",length = 45,nullable = false)
    private String infoBeca;
    @Column(name = "beneficioBeca",length = 45,nullable = false)
    private String beneficioBeca;
    @Column(name = "condicionBeca",length = 45,nullable = false)
    private String condicionBeca;

    @ManyToOne
    @JoinColumn(name = "idOfertaEmpleo", nullable = false)
    private OfertaEmpleo ofertaEmpleo;

    public Beca() {
        super();
    }

    public Beca(int idBeca, String infoBeca, String beneficioBeca, String condicionBeca, OfertaEmpleo ofertaEmpleo) {
        this.idBeca = idBeca;
        this.infoBeca = infoBeca;
        this.beneficioBeca = beneficioBeca;
        this.condicionBeca = condicionBeca;
        this.ofertaEmpleo = ofertaEmpleo;
    }

    public int getIdBeca() {
        return idBeca;
    }
    public void setIdBeca(int idBeca) {
        this.idBeca = idBeca;
    }

    public String getInfoBeca() {
        return infoBeca;
    }
    public void setInfoBeca(String infoBeca) {
        this.infoBeca = infoBeca;
    }

    public String getBeneficioBeca() {
        return beneficioBeca;
    }
    public void setBeneficioBeca(String beneficioBeca) {
        this.beneficioBeca = beneficioBeca;
    }

    public String getCondicionBeca() {
        return condicionBeca;
    }
    public void setCondicionBeca(String condicionBeca) {
        this.condicionBeca = condicionBeca;
    }

    public OfertaEmpleo getOfertaEmpleo() {
        return ofertaEmpleo;
    }
    public void setOfertaEmpleo(OfertaEmpleo ofertaEmpleo) {
        this.ofertaEmpleo = ofertaEmpleo;
    }
}
