package pe.edu.upc.youngWorker.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.youngWorker.entities.Beca;
import pe.edu.upc.youngWorker.serviceinterfaces.IBecaService;

import java.text.ParseException;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/becas")
public class BecaController {
    @Autowired
    private IBecaService bService;

    @PostMapping
    public void registrar(@RequestBody Beca b) {
        bService.insertar(b);
    }

    @PutMapping
    public void modificar(@RequestBody Beca b) {
        bService.insertar(b);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable("id") Integer id) {
        bService.eliminar(id);
    }

    @GetMapping
    public List<Beca> listar() {
        return bService.listar();

    }

    @PostMapping("/buscar")
    public List<Beca> buscar(@RequestBody Beca b) throws ParseException {

        List<Beca> listaVehiculos;
        listaVehiculos = bService.buscarBeca(b.getInfoBeca());
        if (listaVehiculos.isEmpty()) {

            listaVehiculos = bService.buscarEmpleo(b.getOfertaEmpleo().getInformaEmpleo());
        }
        return listaVehiculos;

    }
    @GetMapping("/{id}")
    public Optional<Beca> listarId(@PathVariable("id") Integer id) {
        return bService.listarId(id);
    }
}
