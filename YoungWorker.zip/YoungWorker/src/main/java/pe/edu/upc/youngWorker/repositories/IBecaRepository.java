package pe.edu.upc.youngWorker.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pe.edu.upc.youngWorker.entities.Beca;
import pe.edu.upc.youngWorker.entities.OfertaEmpleo;

import java.util.List;
@Repository
public interface IBecaRepository extends JpaRepository<Beca,Integer> {
    @Query("from Beca b where b.infoBeca like %:infoBeca")
    List<Beca> buscarBeca(@Param("infoBeca") String infoBeca);

    @Query("from Beca b where  b.ofertaEmpleo.informaEmpleo like %:informaEmpleo")
    List<Beca> buscarOfertaEmpleo(@Param("informaEmpleo") String informaEmpleo);

}
