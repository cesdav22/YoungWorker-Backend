package pe.edu.upc.youngWorker.serviceimpls;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.youngWorker.entities.Beca;
import pe.edu.upc.youngWorker.repositories.IBecaRepository;
import pe.edu.upc.youngWorker.serviceinterfaces.IBecaService;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
public class BecaServiceImpl implements IBecaService {
    @Autowired
    private IBecaRepository bRepository;

    @Override
    @Transactional
    public boolean insertar(Beca beca) {
        Beca objBeca = bRepository.save(beca);
        if (objBeca == null) {
            return false;
        } else {
            return true;
        }
    }

    @Override
    @Transactional
    public void eliminar(int idVehiculo) {

        bRepository.deleteById(idVehiculo);

    }

    @Override
    public Optional<Beca> listarId(int idVehiculo) {

        return bRepository.findById(idVehiculo);
    }

    @Override
    public List<Beca> listar() {
        return bRepository.findAll();
    }

    @Override
    public List<Beca> buscarEmpleo(String informaEmpleo) {
        return bRepository.buscarOfertaEmpleo(informaEmpleo);
    }

    @Override
    public List<Beca> buscarBeca(String infoBeca) {
        return bRepository.buscarBeca(infoBeca);
    }
}
