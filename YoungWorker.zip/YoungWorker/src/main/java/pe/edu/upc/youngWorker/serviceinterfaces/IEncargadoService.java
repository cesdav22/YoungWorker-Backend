package pe.edu.upc.youngWorker.serviceinterfaces;
import pe.edu.upc.youngWorker.entities.Encargado;
import java.util.List;
public interface IEncargadoService {
	public void insertar(Encargado encargado);
    List<Encargado> list();
    public void delete (int idEncargado);
    List<Encargado>search(String empresa);

}
