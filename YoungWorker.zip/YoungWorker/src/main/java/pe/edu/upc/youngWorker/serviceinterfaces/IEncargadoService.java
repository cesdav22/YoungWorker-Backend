package pe.edu.upc.youngWorker.serviceinterfaces;
import pe.edu.upc.youngWorker.entities.Encargado;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

public interface IEncargadoService {


    @Transactional
    public boolean insertar(Encargado encargado);

    @Transactional
    public void eliminar(int idEncargado);

    public Optional<Encargado> listarId(int idEncargado);

    List<Encargado> listar();

    List<Encargado> buscarUsuario(String nameUsuario);

    List<Encargado> buscarEmpresa(String empresa);
}
