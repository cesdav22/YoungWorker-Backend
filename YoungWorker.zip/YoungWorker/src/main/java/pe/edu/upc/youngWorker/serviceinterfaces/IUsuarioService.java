package pe.edu.upc.youngWorker.serviceinterfaces;
import pe.edu.upc.youngWorker.entities.Usuario;

import java.util.List;
import java.util.Optional;

public interface IUsuarioService {


    public void insertar(Usuario usuario);

    List<Usuario> listar();

    public void eliminar(int idUsuario);

    public Optional<Usuario> listarId(int idUsuario);

    List<Usuario> buscarNombre(String nombreUsuario);
}
