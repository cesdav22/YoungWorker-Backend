package pe.edu.upc.youngWorker.serviceimpls;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.youngWorker.entities.Plan;
import pe.edu.upc.youngWorker.repositories.IPlanRepository;
import pe.edu.upc.youngWorker.serviceinterfaces.IPlanService;

import java.util.List;
import java.util.Optional;
@Service
public class PlanServiceImpl implements IPlanService {
    @Autowired
    private IPlanRepository pRepository;

    @Override
    public void insertar(Plan plan) {
        pRepository.save(plan);
    }

    @Override
    public List<Plan> listar() {

        return pRepository.findAll();
    }

    @Override
    public void eliminar(int idPlan) {
        pRepository.deleteById(idPlan);
    }

    @Override
    public Optional<Plan> listarId(int idPlan){
        return pRepository.findById(idPlan);
    }

    @Override
    public List<Plan> buscarNombre(String nombrePlan) {
        return pRepository.buscarPlan(nombrePlan);
    }
}
