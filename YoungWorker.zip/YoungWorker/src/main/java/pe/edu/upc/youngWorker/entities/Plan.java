package pe.edu.upc.youngWorker.entities;

import javax.persistence.*;

@Entity
@Table(name = "Plan")

public class Plan{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idPlan;
    @Column(name = "infoPlanes",length = 45,nullable = false)
    private String infoPlan;
    @Column(name = "infoDescripcion",length = 45,nullable = false)
    private String descripcionPlan;
    @Column(name = "infoBeneficio",length = 45,nullable = false)
    private String beneficioPlan;


    public Plan(int idPlan, String infoPlan, String descripcion, String beneficio) {
        this.idPlan = idPlan;
        this.infoPlan = infoPlan;
        this.descripcionPlan = descripcion;
        this.beneficioPlan = beneficio;
    }

    public Plan() {
        super();
    }


    public int getIdPlan() {
        return idPlan;
    }
    public void setIdPlan(int idPlan) {
        this.idPlan = idPlan;
    }

    public String getinfoPlan(){
        return infoPlan;
    }
    public void setinfoPlan(String nombrePlan){
        this.infoPlan = infoPlan;
    }

    public String getDescripcion() {
        return descripcionPlan;
    }
    public void setDescripcion(String descripcion) {
        this.descripcionPlan = descripcion;
    }

    public String getBeneficio() {
        return beneficioPlan;
    }
    public void setBeneficio(String beneficio) {
        this.beneficioPlan = beneficio;
    }
}
