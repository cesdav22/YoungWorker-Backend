package pe.edu.upc.youngWorker.serviceimpls;

import pe.edu.upc.youngWorker.entities.Usuario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.youngWorker.repositories.IUsuarioRepository;
import pe.edu.upc.youngWorker.serviceinterfaces.IUsuarioService;

import java.util.List;
import java.util.Optional;

@Service
public class UsuarioServiceImpl implements IUsuarioService {
    @Autowired
    private IUsuarioRepository uRepository;

    @Override
    public void insertar(Usuario usuario){
        uRepository.save(usuario);
    }

    @Override
    public List<Usuario> listar() {
        return uRepository.findAll();
    }

    @Override
    public void eliminar(int idUsuario) {
        uRepository.deleteById(idUsuario);
    }

    @Override
    public Optional<Usuario> listarId(int idUsuario) {
        return uRepository.findById(idUsuario);
    }

    @Override
    public List<Usuario> buscarNombre(String nombreUsuario) {
        return uRepository.buscarUsuario(nombreUsuario);
    }
}
