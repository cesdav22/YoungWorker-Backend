package pe.edu.upc.youngWorker.controllers;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import pe.edu.upc.youngWorker.entities.Encargado;

import pe.edu.upc.youngWorker.serviceinterfaces.IEncargadoService;

@RestController
@RequestMapping("/encargados")
public class EncargadoController {
	@Autowired
	private IEncargadoService cService;

	@PostMapping
	public void registrar(@RequestBody Encargado en) {
		cService.insertar(en);
	}

	@GetMapping
	public List<Encargado> listar() {
		return cService.listar();
	}

	@PutMapping
	public void modificar(@RequestBody Encargado en) {
		cService.insertar(en);
	}

	@DeleteMapping("/{id}")
	public void eliminar(@PathVariable("id") Integer id) {
		cService.eliminar(id);
	}

	@PostMapping("/buscar")
	public List<Encargado> buscar(@RequestBody Encargado en) throws ParseException {

		List<Encargado> listaEncargado;
		listaEncargado = cService.buscarEmpresa(en.getEmpresa());
		if (listaEncargado.isEmpty()) {

			listaEncargado = cService.buscarUsuario(en.getUsuario().getNameUsuario());
		}
		return listaEncargado;
	}
}



