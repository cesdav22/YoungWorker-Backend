package pe.edu.upc.youngWorker.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import pe.edu.upc.youngWorker.entities.Encargado;

import pe.edu.upc.youngWorker.serviceinterfaces.IEncargadoService;

@RestController
@RequestMapping("/encargados")
public class EncargadoController {
	  @Autowired
	    private IEncargadoService cService;

	    @PostMapping
	    public void registrar(@RequestBody Encargado en) {
	        cService.insertar(en);
	    }
	    @GetMapping
	    public List<Encargado> listar() {
	        return cService.list();
	    }
		@DeleteMapping("/{id}")
		public void eliminar(@PathVariable("id")Integer id){
			cService.delete(id);
		}
		@PutMapping
		public void modificar(@RequestBody Encargado en){cService.insertar(en);}
	    @PostMapping("/buscar")
	    public List<Encargado>buscar(@RequestBody Encargado en){
			return cService.search(en.getEmpresa());
	}

}
