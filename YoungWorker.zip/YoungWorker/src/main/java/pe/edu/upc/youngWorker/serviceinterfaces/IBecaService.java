package pe.edu.upc.youngWorker.serviceinterfaces;
import pe.edu.upc.youngWorker.entities.Beca;


import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

public interface IBecaService {


    @Transactional
    boolean insertar(Beca beca);

    @Transactional
    void eliminar(int idBeca);

    Optional<Beca> listarId(int idBeca);

    List<Beca> listar();

    List<Beca> buscarEmpleo(String informaEmpleo);

    List<Beca> buscarBeca(String infoBeca);
}
