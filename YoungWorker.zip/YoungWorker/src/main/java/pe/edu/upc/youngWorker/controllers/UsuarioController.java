package pe.edu.upc.youngWorker.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.youngWorker.entities.Usuario;
import pe.edu.upc.youngWorker.serviceinterfaces.IUsuarioService;

import java.text.ParseException;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {
    @Autowired
    private IUsuarioService uService;

    @PostMapping
    public void registrar(@RequestBody Usuario u) {
        uService.insertar(u);
    }

    @GetMapping
    public List<Usuario> listar() {
        return uService.listar();
    }

    @PutMapping
    public void modificar(@RequestBody Usuario u){
        uService.insertar(u);
    }


    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable("id")Integer id){
        uService.eliminar(id);
    }

    @PostMapping("/buscar")
    public List<Usuario>buscar(@RequestBody String nombreUsuario) throws ParseException{
        List<Usuario> listaUsuario;
        listaUsuario =uService.buscarNombre(nombreUsuario);
        return listaUsuario;
    }

    @GetMapping("/{id}")
    public Optional<Usuario> listarId(@PathVariable("id") Integer id){
        return uService.listarId(id);
    }

}

