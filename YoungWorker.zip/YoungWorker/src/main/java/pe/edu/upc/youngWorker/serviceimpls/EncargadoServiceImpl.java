package pe.edu.upc.youngWorker.serviceimpls;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.youngWorker.entities.Encargado;
import pe.edu.upc.youngWorker.repositories.IEncargadoRepository;
import pe.edu.upc.youngWorker.serviceinterfaces.IEncargadoService;
import java.util.List;
@Service
public class EncargadoServiceImpl implements IEncargadoService{
	 	@Autowired
	    private IEncargadoRepository cR;
	    @Override
	    public void insertar(Encargado encargado) {
	        cR.save(encargado);
	    }

	    @Override
	    public List<Encargado> list() {
	        return cR.findAll();
	    }

	    @Override
	    public void delete(int idEncargado) {
	        cR.deleteById(idEncargado);
	    }

	    @Override
	    public List<Encargado> search(String nombreEncargado) {
	        return cR.buscarEmpresa(nombreEncargado);
	    }


}
