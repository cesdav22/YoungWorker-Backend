package pe.edu.upc.youngWorker.serviceimpls;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.youngWorker.entities.Encargado;
import pe.edu.upc.youngWorker.repositories.IEncargadoRepository;
import pe.edu.upc.youngWorker.serviceinterfaces.IEncargadoService;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
public class EncargadoServiceImpl implements IEncargadoService{

	@Autowired
	private IEncargadoRepository eRepository;

	@Override
	@Transactional
	public boolean insertar(Encargado encargado) {
		Encargado objEncargado = eRepository.save(encargado);
		if (objEncargado == null) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	@Transactional
	public void eliminar(int idEncargado) {

		eRepository.deleteById(idEncargado);

	}

	@Override
	public Optional<Encargado> listarId(int idEncargado) {

		return eRepository.findById(idEncargado);
	}

	@Override
	public List<Encargado> listar() {
		return eRepository.findAll();
	}

	@Override
	public List<Encargado> buscarUsuario(String nameUsuario) {
		return eRepository.buscarUsuario(nameUsuario);
	}

	@Override
	public List<Encargado> buscarEmpresa(String empresa) {
		return eRepository.buscarEmpresa(empresa);
	}


}
