package pe.edu.upc.youngWorker.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import pe.edu.upc.youngWorker.entities.Encargado;
import java.util.List;
@Repository
public interface IEncargadoRepository extends JpaRepository<Encargado, Integer>{

    @Query("from Encargado e where e.usuario.nameUsuario like %:nameUsuario%")
    List<Encargado> buscarUsuario(@Param("nameUsuario") String nameUsuario);

    @Query("from Encargado c "+ "where c.empresa like %:empresa")
    List<Encargado> buscarEmpresa(@Param("empresa") String empresa);


}
