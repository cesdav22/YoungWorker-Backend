package pe.edu.upc.youngWorker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YoungWorkerApplicationTests {

	@Test
	void contextLoads() {
	}

}
